
export default {
    black: '#000000',
    white: '#ffffff',
    primary: '#021345',
    primaryLight: '#021345',
    secondary: '#00A9A5',
    third: '#4E8098',
    thirdLight: '#FFE9CA'
  }