import Navigation from "./src/navigations";
import ChatScreen from "./src/screens/Chat"

export default function App() {
  return <ChatScreen />;
}
